#### init_location.xlsx
- the config files for the initilization postion of each entity (such as UAV, users, attackers, RIS)

#### data_test.py (should change name)
- to read and show the initialization position of each entity
