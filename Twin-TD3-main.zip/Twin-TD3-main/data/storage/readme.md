# This directory stores all experiments

- Each experiment will be saved as a file project in this directory
- benchmark directory stores all the pretrained DRL for UAV trajectory (agent 2 in the code), which will be used when --trained-uav flag is raised
