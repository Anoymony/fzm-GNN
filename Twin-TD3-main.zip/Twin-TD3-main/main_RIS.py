from env import *
episode_num= 100
step_num = 100
a= int(5/5 * episode_num * step_num)
print(a)